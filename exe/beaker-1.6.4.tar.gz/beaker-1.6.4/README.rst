======
beaker
======

Beaker is a library for caching and sessions for use with web applications and
stand-alone Python scripts and applications. It comes with WSGI middleware for
easy drop-in use with WSGI based web applications, and caching decorators for
ease of use with any Python based application.

Support
=======

beaker is considered feature-complete as the project owners (Ben Bangert, Mike
Bayer) have no additional functionality or development beyond bug fixes
planned. Bugs can be filed on github, should be accompanied by a test case to
retain current code coverage, and should be in a Pull request when ready to be
accepted into the beaker code-base.
